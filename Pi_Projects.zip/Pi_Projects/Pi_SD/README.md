Message : Use Raspberry Pi SPI BUS for read and print file "message.txt" ( in root MicroSD directory).

Directory : Use Raspberry Pi SPI BUS for list root file & dir (16 max ).

Dump : Use Raspberry Pi SPI BUS for read and dump a file ( ex BadApple.bin).
