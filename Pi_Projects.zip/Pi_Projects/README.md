# Raspberry_Projects
Some of my personnal projects for Raspberry Pi

Pi_LCD : C library for control SPI 1.8" LCD Screen ( based on GPIO bcm2835)

Pi_SD : Some exemple for Read a micro SD Card from a shield ( based on GPIO bcm2835 & PetitFatFS)

DF_Player : Simple C code for drive cheap Mini MP3 Player Audio : DFPlay ( based on WiringPi)

BB_DF_Player : GPIO Direct access with Uart bit banging for drive Mini MP3 Player Audio

BB_SD_Reader : GPIO Direct access for generating SPI in bitbang mode,and dump a file (based only on PetitFatFS)
