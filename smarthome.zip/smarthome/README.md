# Server and some client programs for smarthome project based on raspberry Pi
Here is binaries and sourses for my smart-home project. 
It will update time to time, so chek it to find something interesting for you;)
